SELECT COUNT(*) FROM Seller Where Rating > 1000
