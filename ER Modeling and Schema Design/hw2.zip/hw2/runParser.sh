python3 skeleton_parser.py ebay_data/items-*.json && 
sort -u items.dat > item.dat && 
sort -u bidders.dat > bidder.dat && 
sort -u sellers.dat > seller.dat && 
sort -u bids.dat > bid.dat && 
sort -u category.dat > categories.dat

